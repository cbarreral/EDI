jo1 = {}
JSONArray jarr = new JSONArray();
jo1.put("filters",jarr);